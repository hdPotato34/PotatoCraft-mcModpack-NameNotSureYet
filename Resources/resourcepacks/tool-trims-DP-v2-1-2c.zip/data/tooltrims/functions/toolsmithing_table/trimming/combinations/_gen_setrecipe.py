import os

abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)
os.chdir(dname)

type = ["netherite","diamond","iron","golden","stone","wooden"]
tool = ["sword","pickaxe","axe","shovel","hoe"]
trim = ["linear","tracks","charge","frost"]
material = ["amethyst","copper","diamond","emerald","gold","iron","lapis","netherite","quartz","redstone"]
material_name = ["amethyst_shard","copper_ingot","diamond","emerald","gold_ingot","iron_ingot","lapis_lazuli","netherite_ingot","quartz","redstone"]
color = ["#9A5CC6","#B4684D","#6EECD2","#11A036","#DEB12D","#ECECEC","#416E97","#625859","#E3D4C4","#971607"]

order = 0

for k in range(len(trim)):
        for l in range(len(material)):
            customdata = 311000 + order
            order += 1

            lines = f'''item replace block ~ ~ ~ container.24 from block ~ ~ ~ container.20 tooltrims:trims/{trim[k]}_{material[l]}

scoreboard players set .310_trim 310_operation {order}
execute store result score .310_result 310_operation run scoreboard players operation @s 310_tool *= .310_40 310_operation
execute store result score @s 310_combination run scoreboard players operation .310_result 310_operation += .310_trim 310_operation
execute store result block ~ ~ ~ Items[{{Slot:24b}}].tag.combination int 1 run scoreboard players get @s 310_combination

scoreboard players set @s 310_recipe 1'''

            filename = f"{trim[k]}_{material[l]}.mcfunction"

            with open(filename, "w") as file:
                file.write(lines)